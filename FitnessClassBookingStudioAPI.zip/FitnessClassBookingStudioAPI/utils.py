from pytz import timezone, utc

def convert_to_timezone(dt, tz_str):
    return utc.localize(dt).astimezone(timezone(tz_str))