from pydantic import BaseModel, EmailStr
from datetime import datetime

class FitnessClassBase(BaseModel):
    name: str
    datetime: datetime
    instructor: str
    slots: int

class ShowClass(FitnessClassBase):
    id: int

    model_config = {
        "from_attributes": True
    }

class BookingCreate(BaseModel):
    class_id: int
    client_name: str
    client_email: EmailStr

class ShowBooking(BookingCreate):
    id: int

    model_config = {
        "from_attributes": True
    }
