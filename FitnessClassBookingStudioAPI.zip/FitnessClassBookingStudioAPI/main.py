from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from sqlalchemy.orm import Session
import logging
import models, schemas
from database import engine, SessionLocal, Base
from datetime import datetime
import pytz

# Setup Logging
logging.basicConfig(filename="app.log", level=logging.INFO)

# Initialize DB
Base.metadata.create_all(bind=engine)

# FastAPI App
app = FastAPI()

# Allow all origins (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Timezone: IST default
IST = pytz.timezone("Asia/Kolkata")

@app.get("/classes", response_model=list[schemas.ShowClass])
def get_classes(request: Request, db: Session = Depends(get_db)):
    tz = request.headers.get("timezone", "Asia/Kolkata")
    classes = db.query(models.FitnessClass).all()
    for c in classes:
        c.datetime = c.datetime.astimezone(pytz.timezone(tz))
    return classes

@app.post("/book", response_model=schemas.ShowBooking)
def book_class(booking: schemas.BookingCreate, db: Session = Depends(get_db)):
    fitness_class = db.query(models.FitnessClass).filter(models.FitnessClass.id == booking.class_id).first()
    if not fitness_class:
        raise HTTPException(status_code=404, detail="Class not found")

    if fitness_class.slots <= 0:
        logging.warning(f"Overbooking attempt by {booking.client_email}")
        raise HTTPException(status_code=400, detail="No slots available for this class")

    # Check for duplicate booking
    existing = db.query(models.Booking).filter(
        models.Booking.class_id == booking.class_id,
        models.Booking.client_email == booking.client_email
    ).first()
    if existing:
        raise HTTPException(status_code=409, detail="You have already booked this class")

    # Proceed with booking
    fitness_class.slots -= 1
    new_booking = models.Booking(**booking.dict())
    db.add(new_booking)
    db.commit()
    db.refresh(new_booking)
    logging.info(f"Booking successful: {booking.client_email} -> class {booking.class_id}")
    return new_booking

@app.get("/bookings", response_model=list[schemas.ShowBooking])
def get_bookings(client_email: str, db: Session = Depends(get_db)):
    return db.query(models.Booking).filter(models.Booking.client_email == client_email).all()

# Seed sample classes
@app.on_event("startup")
def seed_data():
    db = SessionLocal()
    if db.query(models.FitnessClass).count() == 0:
        classes = [
            models.FitnessClass(name="Yoga", datetime=IST.localize(datetime(2025, 7, 6, 7, 0)), instructor="Aman", slots=5),
            models.FitnessClass(name="Zumba", datetime=IST.localize(datetime(2025, 7, 6, 9, 0)), instructor="Ankur", slots=5),
            models.FitnessClass(name="HIIT", datetime=IST.localize(datetime(2025, 7, 6, 18, 0)), instructor="Ritika", slots=5),
        ]
        db.add_all(classes)
        db.commit()

# Global validation error handler
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    logging.error(f"Validation error: {exc.errors()}")
    return JSONResponse(
        status_code=422,
        content={"message": "Validation failed", "details": exc.errors()}
    )
